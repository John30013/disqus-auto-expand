const defaultConfig = { 
  'moreReplies': true, 
  'newReplies': true, 
  'longItems': true, 
  'checkInterval': 5,
  'useDarkTheme': false,
  'doDebug': false 
};
