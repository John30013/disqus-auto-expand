const defaultConfig = {
  moreReplies: true,
  newReplies: true,
  longItems: true,
  checkInterval: 5,
  stopAutoplay: true,
  openinNewWindow: true,
  useDarkTheme: false,
  doDebug: false,
};
